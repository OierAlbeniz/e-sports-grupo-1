package Controlador.ControladorBD;

import java.sql.Connection;

public class ControladorTablaEntrenador {
    private Connection con;
    public ControladorTablaEntrenador(Connection con) {
        this.con = con;
    }
}
