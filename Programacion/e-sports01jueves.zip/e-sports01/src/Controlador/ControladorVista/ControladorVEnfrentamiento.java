package Controlador.ControladorVista;

public class ControladorVEnfrentamiento {
}
