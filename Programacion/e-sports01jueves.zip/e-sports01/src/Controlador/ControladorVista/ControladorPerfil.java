package Controlador.ControladorVista;
import Vista.VistaPerfil;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorPerfil {
private Perfil p;
    public ControladorPerfil() {
        p = new Perfil();
        
    }



    public class Perfil implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("holaaa");            }
    }
}
