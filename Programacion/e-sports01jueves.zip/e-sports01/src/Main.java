import Controlador.ControladorPrincipal;

import java.awt.*;
import java.io.File;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws Exception {
        ControladorPrincipal cp = new ControladorPrincipal();
    }
}